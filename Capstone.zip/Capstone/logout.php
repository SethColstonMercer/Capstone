<?php
session_start();
session_destroy();
// Redirect to the login page:
header('Location: loginindex.html');
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="loginstyle.css" rel="stylesheet" type="text/css">
</head>

<body>
</body>
</html>